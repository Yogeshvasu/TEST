from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import Routes
from app.routes.ask import router as ask_router
from app.routes.polly import router as polly_router
from app.routes.transcribe import router as transcribe_router
from app.routes.conversation import router as conversation_router

# Initialize FastAPI App
app = FastAPI()

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routes
app.include_router(ask_router, prefix="/ask")
app.include_router(polly_router, prefix="/polly")
app.include_router(transcribe_router, prefix="/upload-audio")
app.include_router(conversation_router, prefix="/conversation")

# Run on Startup
@app.on_event("startup")
async def startup_event():
    from app.dependencies import cache_s3_files
    cache_s3_files()

# Run Server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
