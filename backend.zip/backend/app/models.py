from pydantic import BaseModel

class ChatRequest(BaseModel):
    question: str

class TranslateRequest(BaseModel):
    text: str
    source_language: str = "ja"
    target_language: str = "en"

class PollyRequest(BaseModel):
    text: str
    voice_id: str = "Mizuki"
