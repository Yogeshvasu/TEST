from app.config import s3_client, S3_BUCKET_NAME

cached_pdfs, cached_images, cached_tables = {}, {}, {}

def cache_s3_files():
    """Caches S3 PDF, Image, and Table Files"""
    global cached_pdfs, cached_images, cached_tables
    cached_pdfs = {key.split('/')[-1].split('.')[0]: key for key in list_s3_objects("pdfs/")}
    cached_images = {key: key.split("Sort")[-1].split("_")[0] for key in list_s3_objects("images/") if "Sort" in key}
    cached_tables = {key: key.split("Sort")[-1].split("_")[0] for key in list_s3_objects("tables/") if "Sort" in key}

def list_s3_objects(prefix):
    """Lists objects in S3 based on prefix"""
    keys = []
    params = {"Bucket": S3_BUCKET_NAME, "Prefix": prefix}
    while True:
        response = s3_client.list_objects_v2(**params)
        keys.extend([obj["Key"] for obj in response.get("Contents", [])])
        if not response.get("IsTruncated"):
            break
        params["ContinuationToken"] = response.get("NextContinuationToken")
    return keys
