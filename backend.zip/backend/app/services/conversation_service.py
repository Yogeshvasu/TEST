from app.config import conversation_table
from datetime import datetime

class ConversationService:
    @staticmethod
    def store_conversation(session_id: str, question: str, response: str):
        """Stores conversation history in DynamoDB"""
        conversation_table.put_item(Item={
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat(),
            "question": question,
            "response": response
        })
        return {"status": "success"}

    @staticmethod
    def get_conversation_history(session_id: str):
        """Retrieves conversation history from DynamoDB"""
        response = conversation_table.query(
            KeyConditionExpression="session_id = :session_id",
            ExpressionAttributeValues={":session_id": session_id}
        )
        return response.get("Items", [])
