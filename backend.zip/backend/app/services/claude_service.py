import json
import time
from app.config import bedrock_client
from app.services.opensearch_service import get_relevant_docs_and_assets

def invoke_claude_model(request_body):
    """Calls Claude API with backoff for rate limits"""
    for attempt in range(5):
        try:
            response = bedrock_client.invoke_model(
                modelId="anthropic.claude-v2:1",
                body=json.dumps(request_body),
                accept="application/json",
                contentType="application/json",
            )
            return json.loads(response["body"].read().decode("utf-8"))["completion"]
        except bedrock_client.exceptions.ThrottlingException:
            time.sleep(2 ** attempt)
    return "Error: Claude API limit exceeded. Try again later."

def generate_answer_with_claude(question, retrieved_data):
    """Generates an answer using Claude"""
    
    if not retrieved_data["text"]:
        return {
            "answer": "⚠️ I couldn't find relevant content in the available documents to answer your question.",
            "page_links": [],
            "relevant_images": [],
            "relevant_tables": []
        }

    context = "\n".join(retrieved_data["text"])
    pdf_links = "\n".join(retrieved_data["page_links"])

    prompt_text = f"""
    Human: Below is relevant document context to answer the question.

    Context:
    {context}

    PDF Links:
    {pdf_links}

    Human: {question}
    Assistant:
    """

    request_body = {"prompt": prompt_text.strip(), "max_tokens_to_sample": 300, "temperature": 0.5}
    return {"answer": invoke_claude_model(request_body), "page_links": retrieved_data["page_links"]}
