from app.config import polly_client, S3_BUCKET_NAME, s3_client
import time

class PollyService:
    @staticmethod
    def generate_speech(text, voice_id="Mizuki"):
        """Generates speech using AWS Polly"""
        response = polly_client.synthesize_speech(Text=text, OutputFormat="mp3", VoiceId=voice_id)
        audio_filename = f"polly_audio/{int(time.time())}.mp3"
        
        # Upload to S3
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=audio_filename,
            Body=response["AudioStream"].read(),
            ContentType="audio/mpeg"
        )
        
        return f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{audio_filename}"
