import requests
import json
from app.config import OPENSEARCH_ENDPOINT, INDEX_NAME, HEADERS, S3_BUCKET_NAME

def get_relevant_docs_and_assets(query):
    """Retrieve relevant documents from OpenSearch"""
    search_payload = {
        "query": {
            "bool": {
                "should": [{"match": {"content": {"query": query, "fuzziness": "AUTO", "boost": 5}}}],
                "minimum_should_match": 1
            }
        },
        "_source": ["content", "page_number", "s3_key"],
        "size": 2
    }
    
    response = requests.get(f"{OPENSEARCH_ENDPOINT}/{INDEX_NAME}/_search", headers=HEADERS, data=json.dumps(search_payload))

    if response.status_code != 200:
        return {"text": [], "page_links": [], "s3_key": None, "pages": []}

    hits = response.json().get("hits", {}).get("hits", [])
    if not hits:
        return {"text": [], "page_links": [], "s3_key": None, "pages": []}

    relevant_docs, page_links, relevant_pages, relevant_s3_key = [], [], [], None
    for hit in hits:
        content, page_number, s3_key = hit["_source"]["content"], hit["_source"]["page_number"], hit["_source"]["s3_key"]
        if not s3_key.startswith("pdfs/"):
            continue
        relevant_docs.append(content)
        page_links.append(f"https://s3.amazonaws.com/{s3_key}#page={page_number}")
        relevant_pages.append(page_number)
        relevant_s3_key = s3_key

    return {"text": relevant_docs, "page_links": page_links, "s3_key": relevant_s3_key, "pages": relevant_pages}
