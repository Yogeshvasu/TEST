import boto3
import time
from app.config import S3_BUCKET_NAME, s3_client

class S3Service:
    @staticmethod
    def upload_file(file, filename):
        """Uploads a file to S3 and returns the file URL"""
        s3_client.upload_fileobj(file, S3_BUCKET_NAME, filename)
        return f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{filename}"

    @staticmethod
    def generate_presigned_url(s3_key, expiration=3600):
        """Generates a presigned URL for downloading a file from S3"""
        return s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': S3_BUCKET_NAME, 'Key': s3_key},
            ExpiresIn=expiration
        )

    @staticmethod
    def list_s3_objects(prefix):
        """Lists all objects from S3 for a given prefix"""
        keys = []
        params = {"Bucket": S3_BUCKET_NAME, "Prefix": prefix}
        while True:
            response = s3_client.list_objects_v2(**params)
            keys.extend([obj["Key"] for obj in response.get("Contents", [])])
            if not response.get("IsTruncated"):
                break
            params["ContinuationToken"] = response.get("NextContinuationToken")
        return keys
