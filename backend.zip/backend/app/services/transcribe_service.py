import uuid
import time
import requests
from app.config import transcribe_client, S3_BUCKET_NAME, s3_client

class TranscribeService:
    @staticmethod
    def upload_audio_to_s3(file, filename):
        """Uploads audio to S3"""
        s3_client.upload_fileobj(file, S3_BUCKET_NAME, filename)
        return f"s3://{S3_BUCKET_NAME}/{filename}"

    @staticmethod
    def start_transcription_job(audio_uri):
        """Starts an AWS Transcribe job"""
        job_name = f"transcribe-job-{uuid.uuid4()}"
        transcribe_client.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={"MediaFileUri": audio_uri},
            MediaFormat="wav",
            LanguageCode="en-US"
        )
        return job_name

    @staticmethod
    def get_transcription_text(job_name):
        """Retrieves the transcription result"""
        while True:
            response = transcribe_client.get_transcription_job(TranscriptionJobName=job_name)
            status = response["TranscriptionJob"]["TranscriptionJobStatus"]
            if status == "COMPLETED":
                transcript_url = response["TranscriptionJob"]["Transcript"]["TranscriptFileUri"]
                transcript_data = requests.get(transcript_url).json()
                return transcript_data["results"]["transcripts"][0]["transcript"]
            elif status == "FAILED":
                return "Transcription Failed"
            time.sleep(5)
