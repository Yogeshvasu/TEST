import boto3

# AWS Region
REGION = "ap-northeast-1"

# Amazon OpenSearch and S3 Configuration
S3_BUCKET_NAME = "bedrock-model-012"
OPENSEARCH_ENDPOINT = "https://search-test-dev-wlgze3fcnwguqsieusl5c4wjoa.ap-northeast-1.es.amazonaws.com"
INDEX_NAME = "document-index"
HEADERS = {"Content-Type": "application/json", "Authorization": f"Basic dGVzdDpNYWxhdmFzdUAxMjM="}

# Initialize AWS Clients
s3_client = boto3.client("s3", region_name=REGION)
bedrock_client = boto3.client("bedrock-runtime", region_name=REGION)
polly_client = boto3.client("polly", region_name=REGION)
dynamodb = boto3.resource("dynamodb", region_name=REGION)
conversation_table = dynamodb.Table("ConversationHistory")
transcribe_client = boto3.client("transcribe", region_name=REGION)