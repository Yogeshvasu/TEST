from fastapi import APIRouter
from app.services.opensearch_service import get_relevant_docs_and_assets
from app.services.claude_service import generate_answer_with_claude

router = APIRouter()

@router.get("/")
async def ask_question(question: str):
    retrieved_data = get_relevant_docs_and_assets(question)
    response = generate_answer_with_claude(question, retrieved_data)
    return response
