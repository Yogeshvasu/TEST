from fastapi import APIRouter, HTTPException, File, UploadFile
from app.services.transcribe_service import TranscribeService
import uuid

router = APIRouter()

@router.post("/")
async def upload_audio(file: UploadFile = File(...)):
    """Uploads an audio file to S3 and returns its transcript"""
    try:
        filename = f"transcribe_audio/{uuid.uuid4()}.wav"
        audio_uri = TranscribeService.upload_audio_to_s3(file.file, filename)
        job_name = TranscribeService.start_transcription_job(audio_uri)
        transcript = TranscribeService.get_transcription_text(job_name)
        return {"transcript": transcript}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
