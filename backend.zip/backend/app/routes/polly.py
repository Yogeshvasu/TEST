from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.polly_service import PollyService

router = APIRouter()

class PollyRequest(BaseModel):
    text: str
    voice_id: str = "Mizuki"

@router.post("/")
def generate_speech(request: PollyRequest):
    """Generates speech audio from text using Amazon Polly"""
    if not request.text:
        raise HTTPException(status_code=400, detail="Text input is required")
    
    try:
        audio_url = PollyService.generate_speech(request.text, request.voice_id)
        return {"audio": audio_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
