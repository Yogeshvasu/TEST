from fastapi import APIRouter, HTTPException
from app.services.conversation_service import ConversationService
from pydantic import BaseModel

router = APIRouter()

class ConversationRequest(BaseModel):
    session_id: str
    question: str
    response: str

@router.post("/")
def store_conversation(data: ConversationRequest):
    try:
        ConversationService.store_conversation(data.session_id, data.question, data.response)
        return {"status": "success", "message": "Conversation stored successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
